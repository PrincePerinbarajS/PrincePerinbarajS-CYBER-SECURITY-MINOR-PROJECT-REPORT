component {

    function index(event, rc, prc){
        event.setView("search");
    }

    function result(event, rc, prc){

        writeOutput("You searched for: " & rc.q);

    }

}
