component {

    function index(event, rc, prc){

        event.setView("login");

    }

    function check(event, rc, prc){

        username = rc.username;
        password = rc.password;

        writeOutput("Logged in as: " & username);

    }

}
