<h1>Search Box</h1>

<form method="GET" action="/search/result">

    <input type="text" name="q">

    <button type="submit">Search</button>

</form>
