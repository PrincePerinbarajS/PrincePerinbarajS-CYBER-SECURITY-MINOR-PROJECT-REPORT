<!DOCTYPE html>
<html>
<head>
    <title>Search</title>
</head>
<body>

<h1>Search Box</h1>

<form method="GET" action="/index.cfm/search/result">

    Search:
    <input type="text" name="q">

    <button type="submit">Search</button>

</form>

</body>
</html>
