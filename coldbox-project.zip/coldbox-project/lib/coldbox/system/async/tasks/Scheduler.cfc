/**
 * The Async Scheduler is in charge of registering scheduled tasks, starting them, monitoring them and shutting them down if needed.
 *
 * Each scheduler is bound to an scheduled executor class. You can override the executor using the `setExecutor()` method if you so desire.
 * The scheduled executor will be named <code>{name}-scheduler</code>
 *
 * In a ColdBox context, you might have the global scheduler in charge of the global tasks and also 1 per module as well in HMVC fashion.
 * In a ColdBox context, this object will inherit from the ColdBox super type as well dynamically at runtime.
 *
 */
component accessors="true" singleton {

	/**
	 * --------------------------------------------------------------------------
	 * Properties
	 * --------------------------------------------------------------------------
	 */

	/**
	 * The name of this scheduler
	 */
	property name="name";

	/**
	 * An ordered struct of all the tasks this scheduler manages
	 */
	property name="tasks" type="struct";

	/**
	 * The Scheduled Executor we are bound to
	 */
	property name="executor";

	/**
	 * The default timezone to use for task executions
	 */
	property name="timezone";

	/**
	 * The default timeout to use when gracefully shutting down this scheduler. Default is 30 seconds.
	 */
	property
		name   ="shutdownTimeout"
		type   ="numeric"
		default="30";

	/**
	 * If this scheduler has been started or not
	 */
	property
		name   ="started"
		type   ="boolean"
		default="false";

	/**
	 * When this scheduler was started
	 */
	property name="startedAt" type="date";

	/**
	 * Constructor
	 *
	 * @name         The name of this scheduler
	 * @asyncManager The async manager we are linked to
	 */
	function init( required name, required asyncManager ){
		// Utility class
		variables.util            = new coldbox.system.core.util.Util();
		// Default shutdown timeout
		variables.shutdownTimeout = 30;
		// Name
		variables.name            = arguments.name;
		// The async manager
		variables.asyncManager    = arguments.asyncManager;
		// The collection of tasks we will run
		variables.tasks           = structNew( "ordered" );
		// Default TimeZone to UTC for all tasks
		variables.timezone        = createObject( "java", "java.time.ZoneId" ).systemDefault();
		// Build out the executor for this scheduler
		createSchedulerExecutor();
		// Bit that denotes if this scheduler has been started or not
		variables.started = false;
		// Send notice
		arguments.asyncManager.out( "√ Scheduler (#arguments.name#) has been registered" );

		return this;
	}

	/**
	 * --------------------------------------------------------------------------
	 * Configuration Methods
	 * --------------------------------------------------------------------------
	 */

	/**
	 * Usually where concrete implementations add their tasks and configs
	 */
	function configure(){
	}

	/**
	 * Set the timezone for all tasks to use using the timezone string identifier
	 *
	 * @see      https:   //docs.oracle.com/en/java/javase/11/docs/api/java.base/java/time/ZoneId.html
	 * @timezone The timezone string identifier
	 */
	Scheduler function setTimezone( required timezone ){
		variables.timezone = createObject( "java", "java.time.ZoneId" ).of( arguments.timezone );
		return this;
	}

	/**
	 * --------------------------------------------------------------------------
	 * Startup/Shutdown Methods
	 * --------------------------------------------------------------------------
	 */

	/**
	 * Startup this scheduler and all of it's scheduled tasks
	 */
	Scheduler function startup(){
		if ( !variables.started ) {
			lock name="scheduler-#getName()#-startup" type="exclusive" timeout="45" throwOnTimeout="true" {
				if ( !variables.started ) {
					// Iterate over tasks and send them off for scheduling
					variables.tasks.each( ( taskName, taskRecord ) => startupTask( taskName ) );
					// Mark scheduler as started
					variables.started   = true;
					variables.startedAt = now();
					// callback
					this.onStartup();
					// Log it
					variables.asyncManager.out( "√ Scheduler (#getname()#) has started!" );
				}
				// end double if not started
			}
			// end lock
		}
		// end if not started

		return this;
	}

	/**
	 * Startup a task in this scheduler.  You can use the task name if registered or the task object itself.
	 * <p>
	 * If the task is disabled, it will not be scheduled.
	 * <p>
	 * If the task is already scheduled, it will not be scheduled again.
	 * <p>
	 * If the task has an error scheduling, it will be marked as such.
	 *
	 *  name, task, future, registeredAt, scheduledAt, disabled, error, errorMessage, stacktrace, inetHost, localIp
	 * }
	 *
	 * @task The task name or task object to startup
	 *
	 * @return The task record struct: {
	 */
	struct function startupTask( any task ){
		var taskRecord = getTaskRecord(
			isSimpleValue( arguments.task ) ? arguments.task : arguments.task.getName()
		);

		// Verify we can start it up the task or not
		if ( taskRecord.task.isDisabled() ) {
			taskRecord.disabled = true;
			variables.asyncManager.out(
				"- Scheduler (#getName()#) skipping task (#taskRecord.task.getName()#) as it is disabled."
			);
			return taskRecord;
		} else {
			// Log scheduling startup
			variables.asyncManager.out(
				"- Scheduler (#getName()#) scheduling task (#taskRecord.task.getName()#)..."
			);
		}

		// Verify that the task record: scheduledAt is empty
		if ( !isNull( taskRecord.scheduledAt ) && len( taskRecord.scheduledAt ) ) {
			variables.asyncManager.out(
				"- Scheduler (#getName()#) skipping task (#taskRecord.task.getName()#) as it is already scheduled."
			);
			return taskRecord;
		}

		// Send it off for scheduling
		try {
			taskRecord.future      = taskRecord.task.start();
			taskRecord.scheduledAt = now();
			variables.asyncManager.out( "√ Task (#taskRecord.task.getName()#) scheduled successfully." );
		} catch ( any e ) {
			variables.asyncManager.err(
				"X Error scheduling task (#taskRecord.task.getName()#) => #e.message# #e.detail#"
			);
			taskRecord.error        = true;
			taskRecord.errorMessage = e.message & e.detail;
			taskRecord.stackTrace   = e.stacktrace;
		}

		return taskRecord;
	}

	/**
	 * Check if this scheduler has started or not
	 */
	boolean function hasStarted(){
		return variables.started;
	}

	/**
	 * Shutdown this scheduler by calling the executor to shutdown and disabling all tasks
	 *
	 * @force   If true, it forces all shutdowns this is usually true when doing reinits
	 * @timeout The timeout in seconds to wait for the shutdown of all tasks, defaults to 30 or whatever you set using the setShutdownTimeout() method
	 */
	Scheduler function shutdown( boolean force = false, numeric timeout = variables.shutdownTimeout ){
		// callback
		this.onShutdown( argumentCollection = arguments );
		// shutdown executor and await termination or kill it now!
		if ( arguments.force ) {
			variables.executor.shutdownNow();
		} else {
			variables.executor.shutdownAndAwaitTermination( arguments.timeout );
		}
		// Remove executor
		variables.asyncManager.deleteExecutor( variables.name & "-scheduler" );
		// Mark it
		variables.started = false;
		// Clear the tasks
		clearTasks();
		// Log it
		variables.asyncManager.out( "√ Scheduler (#getName()#) has been shutdown!" );
		return this;
	}

	/**
	 * Restarts a scheduler by shutting it down, clearing out the tasks, calling `configure`, and starting it again.
	 * Useful when loading tasks from a database or other dynamic sources.
	 *
	 * @force   If true, it forces all shutdowns this is usually true when doing reinits
	 * @timeout The timeout in seconds to wait for the shutdown of all tasks, defaults to 30 or whatever you set using the setShutdownTimeout() method
	 */
	public Scheduler function restart( boolean force = false, numeric timeout = variables.shutdownTimeout ){
		variables.asyncManager.out( "√ Scheduler (#arguments.name#) is being restarted" );
		shutdown( argumentCollection = arguments );
		createSchedulerExecutor();
		configure();
		startup();
		variables.asyncManager.out( "√ Scheduler (#arguments.name#) has been restarted" );
		return this;
	}

	/**
	 * --------------------------------------------------------------------------
	 * Life - Cycle Callbacks
	 * --------------------------------------------------------------------------
	 * These are usually implemented by concrete schedulers to add custom behavior
	 */

	/**
	 * Called before the scheduler is going to be shutdown
	 */
	function onShutdown(){
	}

	/**
	 * Called after the scheduler has registered all schedules
	 */
	function onStartup(){
	}

	/**
	 * Called whenever ANY task fails
	 *
	 * @task      The task that got executed
	 * @exception The ColdFusion exception object
	 */
	function onAnyTaskError( required task, required exception ){
	}

	/**
	 * Called whenever ANY task succeeds
	 *
	 * @task   The task that got executed
	 * @result The result (if any) that the task produced
	 */
	function onAnyTaskSuccess( required task, result ){
	}

	/**
	 * Called before ANY task runs
	 *
	 * @task The task about to be executed
	 */
	function beforeAnyTask( required task ){
	}

	/**
	 * Called after ANY task runs
	 *
	 * @task   The task that got executed
	 * @result The result (if any) that the task produced
	 */
	function afterAnyTask( required task, result ){
	}

	/**
	 * --------------------------------------------------------------------------
	 * Task Methods
	 * --------------------------------------------------------------------------
	 */

	/**
	 * Clear the tasks                      from this scheduler
	 * BEWARE: This will not stop the tasks    , it will just remove them from the scheduler
	 */
	public Scheduler function clearTasks(){
		variables.tasks = structNew( "ordered" );
		return this;
	}

	/**
	 * Register a new task in this scheduler but disable it immediately.  This is useful
	 * when debugging tasks and have the easy ability to disable them.
	 *
	 * @name  The name of this task
	 * @debug Add debugging logs to System out, disabled by default in coldbox.system.async.tasks.ScheduledTask
	 *
	 * @return The registered and disabled Scheduled Task
	 */
	ScheduledTask function xtask( required name, boolean debug = false ){
		return task( argumentCollection = arguments ).disable();
	}

	/**
	 * Register a new task in this scheduler that will be executed once the `startup()` method is called on the scheduler
	 * by the framework.
	 * <p>
	 * If you want to start the task immediately, or dynamically, then call the `startTask( Task task)` method on this
	 * scheduler.  This will make sure the task and it's task records are managed by the scheduler.
	 *
	 * @name  The name of this task
	 * @debug Add debugging logs to System out, disabled by default in coldbox.system.async.tasks.ScheduledTask
	 *
	 * @return a ScheduledTask object so you can work on the registration of the task
	 */
	ScheduledTask function task( required name, boolean debug = false ){
		// Create task with custom name
		var oTask = variables.executor
			// Give me the task broda!
			.newTask( argumentCollection = arguments )
			// Register ourselves in the task
			.setScheduler( this )
			// Set default timezone into the task
			.setTimezone( this.getTimezone().getId() );

		// Create the task record.
		variables.tasks[ arguments.name ] = {
			// task name
			"name"         : arguments.name,
			// task object
			"task"         : oTask,
			// task scheduled future object
			"future"       : "",
			// when it registers
			"registeredAt" : now(),
			// when it's scheduled, else its empty
			"scheduledAt"  : "",
			// Tracks if the task has been disabled for startup purposes
			"disabled"     : false,
			// If there is an error scheduling the task
			"error"        : false,
			// Any error messages when scheduling
			"errorMessage" : "",
			// The exception stacktrace if something went wrong scheduling the task
			"stacktrace"   : "",
			// Server Host
			"inetHost"     : variables.util.discoverInetHost(),
			// Server IP
			"localIp"      : variables.util.getServerIp()
		};

		return oTask;
	}

	/**
	 * Builds out a report for all the registered tasks in this scheduler
	 */
	struct function getTaskStats(){
		// return back a struct of stats for each registered task
		return variables.tasks.map( function( key, record ){
			return arguments.record.task.getStats();
		} );
	}

	/**
	 * Get an array of all the tasks managed by this scheduler
	 */
	array function getRegisteredTasks(){
		var taskKeys = variables.tasks.keyArray();
		taskKeys.sort( "textnocase" );
		return taskKeys;
	}

	/**
	 * Checks if this scheduler manages a task by name
	 *
	 * @name The name of the task to search
	 */
	boolean function hasTask( required name ){
		return variables.tasks.keyExists( arguments.name );
	}

	/**
	 * Get's a task record from the collection by name
	 *
	 * @name The name of the task
	 *
	 * @return The task record struct: { name, task, future, scheduledAt, registeredAt, error, errorMessage, stacktrace }
	 *
	 * @throws UnregisteredTaskException if no task is found under that name
	 */
	struct function getTaskRecord( required name ){
		if ( hasTask( arguments.name ) ) {
			return variables.tasks[ arguments.name ];
		}
		throw( type: "UnregisteredTaskException", message: "No task found with the name: #arguments.name#" );
	}

	/**
	 * Unregister a task from this scheduler
	 *
	 * @name The name of the task to remove
	 *
	 * @throws UnregisteredTaskException if no task is found under that name
	 */
	Scheduler function removeTask( required name ){
		// Remove from executor if registered
		var taskRecord = getTaskRecord( arguments.name );

		// Check if the task has been registered so we can cancel it
		if ( isObject( taskRecord.future ) ) {
			taskRecord.future.cancel( mayInterruptIfRunning = true );
		}

		// Delete it
		variables.tasks.delete( arguments.name );
		return this;
	}

	/**
	 * --------------------------------------------------------------------------
	 * Private helpers
	 * --------------------------------------------------------------------------
	 */

	/**
	 * Get the current thread name
	 */
	private function getThreadName(){
		return getCurrentThread().getName();
	}

	/**
	 * Get the current thread java object
	 */
	private function getCurrentThread(){
		return createObject( "java", "java.lang.Thread" ).currentThread();
	}

	/**
	 * Create a new scheduled executor for this scheduler according to it's name and type
	 */
	private function createSchedulerExecutor(){
		variables.executor = variables.asyncManager.newExecutor(
			name: variables.name & "-scheduler",
			type: "scheduled"
		);
	}

}
