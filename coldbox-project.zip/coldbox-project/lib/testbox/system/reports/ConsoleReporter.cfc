/**
 * Copyright Since 2005 TestBox Framework by Luis Majano and Ortus Solutions, Corp
 * www.ortussolutions.com
 * ---
 * A text reporter that emits to the console via java System out.
 */
component extends="TextReporter" {

	function init(){
		variables.out = createObject( "Java", "java.lang.System" ).out;
		return this;
	}

	/**
	 * Get the name of the reporter
	 */
	function getName(){
		return "Console";
	}

	/**
	 * Do the reporting thing here using the incoming test results
	 * The report should return back in whatever format they desire and should set any
	 * Specific browser types if needed.
	 *
	 * @results    The instance of the TestBox TestResult object to build a report on
	 * @testbox    The TestBox core object
	 * @options    A structure of options this reporter needs to build the report with
	 * @justReturn Boolean flag that if set just returns the content with no content type and buffer reset
	 */
	any function runReport(
		required testbox.system.TestResult results,
		required testbox.system.TestBox testbox,
		struct options     = {},
		boolean justReturn = false
	){
		if ( !arguments.justReturn ) {
			// content type
			getPageContextResponse().setContentType( "text/plain" );
		}

		// bundle stats
		variables.bundleStats = arguments.results.getBundleStats();
		// hide skipped option for filtered runs
		variables.hideSkipped = arguments.options.hideSkipped ?: false;
		// prepare incoming params
		prepareIncomingParams();

		// prepare the report
		savecontent variable="local.report" {
			include "assets/console.cfm";
		}

		// send to console
		variables.out.printLn( reReplace( local.report, "[\r\n]+", chr( 10 ), "all" ) );

		return "";
	}

	/**
	 * The indicator format to use when rendering console output.
	 */
	string function getConsoleFormat(){
		return "console";
	}

}
